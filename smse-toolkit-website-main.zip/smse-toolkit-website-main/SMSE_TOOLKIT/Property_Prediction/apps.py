from django.apps import AppConfig


class PropertyPredictionConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Property_Prediction'
