from mp_api.client import MPRester
with MPRester("AbDJYg7k48wD9VTldHPzzr9BgIMjSflN") as mpr:
    a = list(input("Enter the elements: ").split())
    ids = mpr.summary.search(elements=a, fields=["material_id"])
    ret = []
    for i in ids:
        docs = mpr.materials.get_structure_by_material_id(i.material_id)
        ret.append(docs)
        print(docs)
        print("~" * 50)
        print("~" * 50)
    # for docs in ret:
        