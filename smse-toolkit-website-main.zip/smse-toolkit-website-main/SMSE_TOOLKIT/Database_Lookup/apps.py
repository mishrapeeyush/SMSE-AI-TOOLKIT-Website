from django.apps import AppConfig


class DatabaseLookupConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Database_Lookup'
