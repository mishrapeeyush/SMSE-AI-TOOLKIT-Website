# Interactive Periodic Table with CSS Grid Layout

A Pen created on CodePen.io. Original URL: [https://codepen.io/Tyrandus/pen/YQaexG](https://codepen.io/Tyrandus/pen/YQaexG).

Browserinator's Periodic Table JSON made my take on the periodic table possible. It is a simple exercise with the new CSS grid feature. 